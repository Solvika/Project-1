/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Contact_Service;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

/**
 *
 * @author Nick Christopher
 */
public class Contact{

    
    private final String contactID;
    private String firstName;
    private String lastName;
    private String Address;
    private String Number;

    public Contact(String contactID, String firstName,String lastName,String Number, String Address) {
        this.contactID = contactID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.Address = Address;
        this.Number = Number;
    }

    
    public String getContactID() {
        return contactID;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }
    public String getNumber() {
        return Number;
    }

    public void setNumber(String Number) {
        this.Number = Number;
    }
     public boolean validateContactID(String contactID) {
        if (contactID != null && !contactID.isEmpty() && contactID.length() <= 10)
            return true;

        return false;
    }
    public boolean validatefirstName(String firstName) {
        if (firstName != null && !firstName.isEmpty() && firstName.length() <= 10)
            return true;

        return false;
    }
     public boolean validatelastName(String lastName) {
        if (lastName != null && !lastName.isEmpty()&& lastName.length() <= 10)
            return true;

        return false;
    }
     public boolean validateNumber(String Number) {
        if (Number != null && !Number.isEmpty() && Number.length() <= 10)
            return true;

        return false;
    }
     public boolean validateAddress(String Address) {
        if (Address != null&& !Address.isEmpty() && Address.length() <= 30)
            return true;

        return false;
    }
	public static void main(String[] args)
	{

	}
}

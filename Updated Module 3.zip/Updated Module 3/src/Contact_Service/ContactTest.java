/*
 *
 * 
 * 
 */
package Contact_Service;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Nick Christopher
 */
public class ContactTest {
    
    public ContactTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

   
    @Test
    public void testGetContactID() {
        System.out.println("getContactID");
        Contact instance = new Contact("2342","efg","erre","frec","wert");
        String expResult = "2342";
        String result = instance.getContactID();
        assertEquals(result,expResult);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    
    @Test
    public void testGetFirstName() {
        System.out.println("getFirstName");
        Contact instance = new Contact("2314","efg","erre","frec","wert");
        String expResult = "efg";
        String result = instance.getFirstName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    
    @Test
    public void testSetFirstName() {
        System.out.println("setFirstName");
        String firstName = "abc";
        Contact instance = new Contact("5435","efg","erre","frec","wert");
        instance.setFirstName(firstName);
        assertEquals(firstName,instance.getFirstName());
        // TODO review the generated test code and remove the default call to fail.
        
    }

   
    @Test
    public void testGetLastName() {
        System.out.println("getLastName");
        Contact instance = new Contact("1232","efg","erre","frec","wert");
        String expResult = "erre";
        String result = instance.getLastName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    
    @Test
    public void testSetLastName() {
        System.out.println("setLastName");
        String lastName = "defg";
        Contact instance = new Contact("4534","efg","erre","frec","wert");
        instance.setLastName(lastName);
        assertEquals(lastName,instance.getLastName());
        // TODO review the generated test code and remove the default call to fail.
        
    }

    
    @Test
    public void testGetAddress() {
        System.out.println("getAddress");
        Contact instance = new Contact("8768","efg","erre","frec","wert");
        String expResult = "wert";
        String result = instance.getAddress();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    
    @Test
    public void testSetAddress() {
        System.out.println("setAddress");
        String Address = "123a";
        Contact instance = new Contact("24243","efg","erre","frec","wert");
        instance.setAddress(Address);
        assertEquals(Address,instance.getAddress());
        // TODO review the generated test code and remove the default call to fail.
        
    }

  
    @Test
    public void testGetNumber() {
        System.out.println("getNumber");
        Contact instance = new Contact("8634","efg","erre","frec","wert");
        String expResult = "frec";
        String result = instance.getNumber();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    
    @Test
    public void testSetNumber() {
        System.out.println("setNumber");
        String Number = "123423";
        Contact instance = new Contact("8956","efg","erre","frec","wert");
        instance.setNumber(Number);
        assertEquals(Number,instance.getNumber());
        // TODO review the generated test code and remove the default call to fail.
        
    }

    
    @Test
    public void testValidateID() {
        System.out.println("validateID");
        String contactID = "156773518713";
        Contact instance = new Contact("243525","efg","erre","frec","wert");
        //System.out.println(instance.validateContactID(contactID));
        boolean result = instance.validateContactID(contactID);
        assertEquals(false, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    
    @Test
    public void testValidatefirstName() {
        System.out.println("validatefirstName");
        String firstName = "";
        Contact instance = new Contact("3429","efg","erre","frec","wert");
        boolean expResult = false;
        boolean result = instance.validatefirstName(firstName);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    
    @Test
    public void testValidatelastName() {
        System.out.println("validatelastName");
        String lastName = "";
        Contact instance = new Contact("9907","efg","erre","frec","wert");
        boolean expResult = false;
        boolean result = instance.validatelastName(lastName);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    
    @Test
    public void testValidateNumber() {
    	Contact instance = new Contact("213","ds","143","12345","gjefvj");
    	String number = "12312345";
    	assertEquals(true,instance.validateNumber(number));
    }

    
    @Test
    public void testValidateAddress() {
        System.out.println("validateAddress");
        String Address = "";
        Contact instance = new Contact("65456","efg","erre","frec","wert");
        boolean result = instance.validateAddress(Address);
        assertEquals(false, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Contact.main(args);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    
   
    @Test
    public void testValidateContactID() {
        System.out.println("validateContactID");
        String contactID = "";
        Contact instance = new Contact("0985","efg","erre","frec","wert");
        boolean expResult = false;
        boolean result = instance.validateContactID(contactID);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }
    
}
